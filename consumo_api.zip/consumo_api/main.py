#import requests

#response = requests.get("https://rickandmortyapi.com/api/character")
#data = response.json()
#print(data)

import requests

def fetch_data(endpoint, filters={}):
    url = f"https://rickandmortyapi.com/api/{endpoint}"
    response = requests.get(url, params=filters)

    return response.json() if response.status_code == 200 else None

characters = fetch_data("character")

if characters:
    print(characters)
else:
        
        print("Error fetching data")
print(characters)